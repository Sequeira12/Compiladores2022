#ifndef STRUCTURES_H
#define STRUCTURES_H

typedef struct{
  char *id;
  int line;
  int col;
}id_info;


#endif